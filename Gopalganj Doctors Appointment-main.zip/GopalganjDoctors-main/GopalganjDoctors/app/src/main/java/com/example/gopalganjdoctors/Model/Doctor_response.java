package com.example.gopalganjdoctors.Model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Doctor_response {
    @SerializedName("doctorID")
    @Expose
    public Integer doctorID;
}
