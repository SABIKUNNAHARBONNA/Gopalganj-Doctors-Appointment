package com.example.gopalganjdoctors;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Details extends AppCompatActivity {
    public Button d1, d2, d3, d4, d5, d6, d7, d8, d9, d10, d11, d12, d13, d14, d15, d16, d17, d18, d19, d20, d21, d22, d23, d24, d25, d26, d27, d28, d29, d30, d31, d32, d33, d34, d35, d36, d37, d38, d39, d40, d41, d42, d43, d44, d45, d46, d47, d48, d49, d50, d51, d52, d53, d54, d55, d56, d57, d58, d59, d60, d61, d62, d63, d64, d65, d66, d67, d68, d69, d70, d71;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);
        d1 = findViewById(R.id.d1);
        d2 = findViewById(R.id.d2);
        d3 = findViewById(R.id.d3);
        d4 = findViewById(R.id.d4);
        d5 = findViewById(R.id.d5);
        d6 = findViewById(R.id.d6);
        d7 = findViewById(R.id.d7);
        d8 = findViewById(R.id.d8);
        d9 = findViewById(R.id.d9);
        d10 = findViewById(R.id.d10);
        d11 = findViewById(R.id.d11);
        d12 = findViewById(R.id.d12);
        d13 = findViewById(R.id.d13);
        d14 = findViewById(R.id.d14);
        d15 = findViewById(R.id.d15);
        d16 = findViewById(R.id.d16);
        d17 = findViewById(R.id.d17);
        d18 = findViewById(R.id.d18);
        d19 = findViewById(R.id.d19);
        d20 = findViewById(R.id.d20);
        d21 = findViewById(R.id.d21);
        d22 = findViewById(R.id.d22);
        d23 = findViewById(R.id.d23);
        d24 = findViewById(R.id.d24);
        d25 = findViewById(R.id.d25);
        d26 = findViewById(R.id.d26);
        d27 = findViewById(R.id.d27);
        d28 = findViewById(R.id.d28);
        d29 = findViewById(R.id.d29);
        d30 = findViewById(R.id.d30);
        d31 = findViewById(R.id.d31);
        d32 = findViewById(R.id.d32);
        d33 = findViewById(R.id.d33);
        d34 = findViewById(R.id.d34);
        d35 = findViewById(R.id.d35);
        d36 = findViewById(R.id.d36);
        d37 = findViewById(R.id.d37);
        d38 = findViewById(R.id.d38);
        d39 = findViewById(R.id.d39);
        d40 = findViewById(R.id.d40);
        d41 = findViewById(R.id.d41);
        d42 = findViewById(R.id.d42);
        d43 = findViewById(R.id.d43);
        d44 = findViewById(R.id.d44);
        d45 = findViewById(R.id.d45);
        d46 = findViewById(R.id.d46);
        d47 = findViewById(R.id.d47);
        d48 = findViewById(R.id.d48);
        d49 = findViewById(R.id.d49);
        d50 = findViewById(R.id.d50);
        d51 = findViewById(R.id.d51);
        d52 = findViewById(R.id.d52);
        d53 = findViewById(R.id.d53);
        d54 = findViewById(R.id.d54);
        d55 = findViewById(R.id.d55);
        d56 = findViewById(R.id.d56);
        d57 = findViewById(R.id.d57);
        d58 = findViewById(R.id.d58);
        d59 = findViewById(R.id.d59);
        d60 = findViewById(R.id.d60);
        d61 = findViewById(R.id.d61);
        d62 = findViewById(R.id.d62);
        d63 = findViewById(R.id.d63);
        d64 = findViewById(R.id.d64);
        d65 = findViewById(R.id.d65);
        d66 = findViewById(R.id.d66);
        d67 = findViewById(R.id.d67);
        d68 = findViewById(R.id.d68);
        d69 = findViewById(R.id.d69);
        d70 = findViewById(R.id.d70);
        d71 = findViewById(R.id.d71);

        d1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent call1 = new Intent(Intent.ACTION_DIAL);
                call1.setData(Uri.parse("tel:+8801711308023"));
                startActivity(call1);
            }
        });
        d2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent call2 = new Intent(Intent.ACTION_DIAL);
                call2.setData(Uri.parse("tel:+8801711468692"));
                startActivity(call2);
            }
        });
        d3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent call3 = new Intent(Intent.ACTION_DIAL);
                call3.setData(Uri.parse("tel:+8801711389583"));
                startActivity(call3);
            }
        });
        d4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent call4 = new Intent(Intent.ACTION_DIAL);
                call4.setData(Uri.parse("tel:+8801817574626"));
                startActivity(call4);
            }
        });
        d5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent call5 = new Intent(Intent.ACTION_DIAL);
                call5.setData(Uri.parse("tel:+8801711322777"));
                startActivity(call5);
            }
        });
        d6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent call6 = new Intent(Intent.ACTION_DIAL);
                call6.setData(Uri.parse("tel:+8801778190026"));
                startActivity(call6);
            }
        });
        d7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent call7 = new Intent(Intent.ACTION_DIAL);
                call7.setData(Uri.parse("tel:+8801716753914"));
                startActivity(call7);
            }
        });
        d8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent call8 = new Intent(Intent.ACTION_DIAL);
                call8.setData(Uri.parse("tel:+8801711985461"));
                startActivity(call8);
            }
        });
        d9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent call9 = new Intent(Intent.ACTION_DIAL);
                call9.setData(Uri.parse("tel:+8801712200078"));
                startActivity(call9);
            }
        });
        d10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent call10 = new Intent(Intent.ACTION_DIAL);
                call10.setData(Uri.parse("tel:+8801711201266"));
                startActivity(call10);
            }
        });
        d11.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent call11 = new Intent(Intent.ACTION_DIAL);
                call11.setData(Uri.parse("tel:+8801711440471"));
                startActivity(call11);
            }
        });
        d12.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent call12 = new Intent(Intent.ACTION_DIAL);
                call12.setData(Uri.parse("tel:+8801711860548"));
                startActivity(call12);
            }
        });
        d13.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent call13 = new Intent(Intent.ACTION_DIAL);
                call13.setData(Uri.parse("tel:+8801720072752"));
                startActivity(call13);
            }
        });
        d14.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent call14 = new Intent(Intent.ACTION_DIAL);
                call14.setData(Uri.parse("tel:+8801715625652"));
                startActivity(call14);
            }
        });
        d15.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent call15 = new Intent(Intent.ACTION_DIAL);
                call15.setData(Uri.parse("tel:+8801715026228"));
                startActivity(call15);
            }
        });
        d16.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent call16 = new Intent(Intent.ACTION_DIAL);
                call16.setData(Uri.parse("tel:+8801914122830"));
                startActivity(call16);
            }
        });
        d17.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent call17 = new Intent(Intent.ACTION_DIAL);
                call17.setData(Uri.parse("tel:+8801711706094"));
                startActivity(call17);
            }
        });
        d18.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent call18 = new Intent(Intent.ACTION_DIAL);
                call18.setData(Uri.parse("tel:+8801715072352"));
                startActivity(call18);
            }
        });
        d19.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent call19 = new Intent(Intent.ACTION_DIAL);
                call19.setData(Uri.parse("tel:+8801716105178"));
                startActivity(call19);
            }
        });
        d20.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent call20 = new Intent(Intent.ACTION_DIAL);
                call20.setData(Uri.parse("tel:+8801711947035"));
                startActivity(call20);
            }
        });
        d21.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent call21 = new Intent(Intent.ACTION_DIAL);
                call21.setData(Uri.parse("tel:+8801678055020"));
                startActivity(call21);
            }
        });
        d22.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent call22 = new Intent(Intent.ACTION_DIAL);
                call22.setData(Uri.parse("tel:+8801716667916"));
                startActivity(call22);
            }
        });
        d23.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent call23 = new Intent(Intent.ACTION_DIAL);
                call23.setData(Uri.parse("tel:+8801716451904"));
                startActivity(call23);
            }
        });
        d24.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent call24 = new Intent(Intent.ACTION_DIAL);
                call24.setData(Uri.parse("tel:+8801715285746"));
                startActivity(call24);
            }
        });
        d25.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent call25 = new Intent(Intent.ACTION_DIAL);
                call25.setData(Uri.parse("tel:+8801816443697"));
                startActivity(call25);
            }
        });
        d26.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent call26 = new Intent(Intent.ACTION_DIAL);
                call26.setData(Uri.parse("tel:+8801715222459"));
                startActivity(call26);
            }
        });
        d27.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent call27 = new Intent(Intent.ACTION_DIAL);
                call27.setData(Uri.parse("tel:+8801753209109"));
                startActivity(call27);
            }
        });
        d28.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent call28 = new Intent(Intent.ACTION_DIAL);
                call28.setData(Uri.parse("tel:+8801712112597"));
                startActivity(call28);
            }
        });
        d29.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent call29 = new Intent(Intent.ACTION_DIAL);
                call29.setData(Uri.parse("tel:+8801711006273"));
                startActivity(call29);
            }
        });
        d30.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent call30 = new Intent(Intent.ACTION_DIAL);
                call30.setData(Uri.parse("tel:+8801715471171"));
                startActivity(call30);
            }
        });
        d31.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent call31 = new Intent(Intent.ACTION_DIAL);
                call31.setData(Uri.parse("tel:+8801717970610"));
                startActivity(call31);
            }
        });
        d32.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent call32 = new Intent(Intent.ACTION_DIAL);
                call32.setData(Uri.parse("tel:+8801711231972"));
                startActivity(call32);
            }
        });
        d33.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent call33 = new Intent(Intent.ACTION_DIAL);
                call33.setData(Uri.parse("tel:+8801912195845"));
                startActivity(call33);
            }
        });
        d34.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent call34 = new Intent(Intent.ACTION_DIAL);
                call34.setData(Uri.parse("tel:+8801712200914"));
                startActivity(call34);
            }
        });
        d35.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent call35 = new Intent(Intent.ACTION_DIAL);
                call35.setData(Uri.parse("tel:+8801732303960"));
                startActivity(call35);
            }
        });
        d36.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent call36 = new Intent(Intent.ACTION_DIAL);
                call36.setData(Uri.parse("tel:+8801712505562"));
                startActivity(call36);
            }
        });
        d37.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent call37 = new Intent(Intent.ACTION_DIAL);
                call37.setData(Uri.parse("tel:+8801734670270"));
                startActivity(call37);
            }
        });
        d38.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent call38 = new Intent(Intent.ACTION_DIAL);
                call38.setData(Uri.parse("tel:+8801792060890"));
                startActivity(call38);
            }
        });
        d39.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent call39 = new Intent(Intent.ACTION_DIAL);
                call39.setData(Uri.parse("tel:+8801712159074"));
                startActivity(call39);
            }
        });
        d40.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent call40 = new Intent(Intent.ACTION_DIAL);
                call40.setData(Uri.parse("tel:+8801715469729"));
                startActivity(call40);
            }
        });
        d41.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent call41 = new Intent(Intent.ACTION_DIAL);
                call41.setData(Uri.parse("tel:+8801717102882"));
                startActivity(call41);
            }
        });
        d42.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent call42 = new Intent(Intent.ACTION_DIAL);
                call42.setData(Uri.parse("tel:+8801819219618"));
                startActivity(call42);
            }
        });
        d43.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent call43 = new Intent(Intent.ACTION_DIAL);
                call43.setData(Uri.parse("tel:+8801711832159"));
                startActivity(call43);
            }
        });
        d44.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent call44 = new Intent(Intent.ACTION_DIAL);
                call44.setData(Uri.parse("tel:+8801817525287"));
                startActivity(call44);
            }
        });
        d45.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent call45 = new Intent(Intent.ACTION_DIAL);
                call45.setData(Uri.parse("tel:+8801712582888"));
                startActivity(call45);
            }
        });
        d46.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent call46 = new Intent(Intent.ACTION_DIAL);
                call46.setData(Uri.parse("tel:+8801713649111"));
                startActivity(call46);
            }
        });
        d47.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent call47 = new Intent(Intent.ACTION_DIAL);
                call47.setData(Uri.parse("tel:+8801712160688"));
                startActivity(call47);
            }
        });
        d48.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent call48 = new Intent(Intent.ACTION_DIAL);
                call48.setData(Uri.parse("tel:+8801711208187"));
                startActivity(call48);
            }
        });
        d49.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent call49 = new Intent(Intent.ACTION_DIAL);
                call49.setData(Uri.parse("tel:+8801711447417"));
                startActivity(call49);
            }
        });
        d50.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent call50 = new Intent(Intent.ACTION_DIAL);
                call50.setData(Uri.parse("tel:+8801711607755"));
                startActivity(call50);
            }
        });
        d51.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent call51 = new Intent(Intent.ACTION_DIAL);
                call51.setData(Uri.parse("tel:+8801818652987"));
                startActivity(call51);
            }
        });
        d52.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent call52 = new Intent(Intent.ACTION_DIAL);
                call52.setData(Uri.parse("tel:+8801978727686"));
                startActivity(call52);
            }
        });
        d53.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent call53 = new Intent(Intent.ACTION_DIAL);
                call53.setData(Uri.parse("tel:+8801712142047"));
                startActivity(call53);
            }
        });
        d54.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent call54 = new Intent(Intent.ACTION_DIAL);
                call54.setData(Uri.parse("tel:+8801717322300"));
                startActivity(call54);
            }
        });
        d55.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent call55 = new Intent(Intent.ACTION_DIAL);
                call55.setData(Uri.parse("tel:+8801718086509"));
                startActivity(call55);
            }
        });
        d56.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent call56 = new Intent(Intent.ACTION_DIAL);
                call56.setData(Uri.parse("tel:+8801730324778"));
                startActivity(call56);
            }
        });
        d57.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent call57 = new Intent(Intent.ACTION_DIAL);
                call57.setData(Uri.parse("tel:+8801718607269"));
                startActivity(call57);
            }
        });
        d58.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent call58 = new Intent(Intent.ACTION_DIAL);
                call58.setData(Uri.parse("tel:+8801712622715"));
                startActivity(call58);
            }
        });
        d59.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent call59 = new Intent(Intent.ACTION_DIAL);
                call59.setData(Uri.parse("tel:+8801712280747"));
                startActivity(call59);
            }
        });
        d60.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent call60 = new Intent(Intent.ACTION_DIAL);
                call60.setData(Uri.parse("tel:+8801819158636"));
                startActivity(call60);
            }
        });
        d61.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent call61 = new Intent(Intent.ACTION_DIAL);
                call61.setData(Uri.parse("tel:+8801914176823"));
                startActivity(call61);
            }
        });
        d62.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent call62 = new Intent(Intent.ACTION_DIAL);
                call62.setData(Uri.parse("tel:+8801922644868"));
                startActivity(call62);
            }
        });
        d63.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent call63 = new Intent(Intent.ACTION_DIAL);
                call63.setData(Uri.parse("tel:+8801749888417"));
                startActivity(call63);
            }
        });
        d64.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent call64 = new Intent(Intent.ACTION_DIAL);
                call64.setData(Uri.parse("tel:+8801757292752"));
                startActivity(call64);
            }
        });
        d65.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent call65 = new Intent(Intent.ACTION_DIAL);
                call65.setData(Uri.parse("tel:+8801712108781"));
                startActivity(call65);
            }
        });
        d66.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent call66 = new Intent(Intent.ACTION_DIAL);
                call66.setData(Uri.parse("tel:+8801712072849"));
                startActivity(call66);
            }
        });
        d67.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent call67 = new Intent(Intent.ACTION_DIAL);
                call67.setData(Uri.parse("tel:+8801736804039"));
                startActivity(call67);
            }
        });
        d68.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent call68 = new Intent(Intent.ACTION_DIAL);
                call68.setData(Uri.parse("tel:+8801815656196"));
                startActivity(call68);
            }
        });
        d69.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent call69 = new Intent(Intent.ACTION_DIAL);
                call69.setData(Uri.parse("tel:+8801712651404"));
                startActivity(call69);
            }
        });
        d70.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent call70 = new Intent(Intent.ACTION_DIAL);
                call70.setData(Uri.parse("tel:+8801673608723"));
                startActivity(call70);
            }
        });
        d71.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent call71 = new Intent(Intent.ACTION_DIAL);
                call71.setData(Uri.parse("tel:+8801717487506"));
                startActivity(call71);
            }
        });

    }
}