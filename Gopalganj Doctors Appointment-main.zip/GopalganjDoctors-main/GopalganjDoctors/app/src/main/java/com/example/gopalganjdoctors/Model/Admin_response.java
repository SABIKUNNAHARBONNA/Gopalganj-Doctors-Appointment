package com.example.gopalganjdoctors.Model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Admin_response {
    @SerializedName("adminID")
    @Expose
    public String adminID;


}
